const database =  'BD3-NoSQL-AtlasMongoDB'; //const que representa o nome do banco
const collection =  'bd3-nosql-atv1'; //const que representa o nome da collection
use(database);//define o banco que será usado, se não existir ele cria

db.createCollection(collection)//cria a collection





                // |
                // |
                // |
                // v
                //caso seja tudo no msm arquivo, é so descomentar e apagar os outros 
                //caso seja separado, só ignora isso tudo, tem nos outros arquivos



// /*Inserir 10 alunos */
// db['bd3-nosql-atv1'].insertMany(
//   [
//     {
//       "cod_aluno": 1,
//       "cod_turma": 101,
//       "nome": "Maria Silva",
//       "cpf": "123.456.789-00",
//       "rg": "12.345.678-1",
//       "telefone_aluno": "(11) 91234-5678",
//       "telefone_responsavel": "(11) 98765-4321",
//       "email": "maria.silva@email.com",
//       "data_nascimento": "2005-05-12T00:00:00Z"
//     },
//     {
//       "cod_aluno": 2,
//       "cod_turma": 102,
//       "nome": "João Souza",
//       "cpf": "234.567.890-11",
//       "rg": "23.456.789-2",
//       "telefone_aluno": "(11) 92345-6789",
//       "telefone_responsavel": "(11) 99876-5432",
//       "email": "joao.souza@email.com",
//       "data_nascimento": "2004-03-22T00:00:00Z"
//     },
//     {
//       "cod_aluno": 3,
//       "cod_turma": 101,
//       "nome": "Ana Oliveira",
//       "cpf": "345.678.901-22",
//       "rg": "34.567.890-3",
//       "telefone_aluno": "(11) 93456-7890",
//       "telefone_responsavel": "(11) 98765-4320",
//       "email": "ana.oliveira@email.com",
//       "data_nascimento": "2006-08-15T00:00:00Z"
//     },
//     {
//       "cod_aluno": 4,
//       "cod_turma": 103,
//       "nome": "Pedro Santos",
//       "cpf": "456.789.012-33",
//       "rg": "45.678.901-4",
//       "telefone_aluno": "(11) 94567-8901",
//       "telefone_responsavel": "(11) 97654-3210",
//       "email": "pedro.santos@email.com",
//       "data_nascimento": "2003-11-30T00:00:00Z"
//     },
//     {
//       "cod_aluno": 5,
//       "cod_turma": 102,
//       "nome": "Julia Costa",
//       "cpf": "567.890.123-44",
//       "rg": "56.789.012-5",
//       "telefone_aluno": "(11) 95678-9012",
//       "telefone_responsavel": "(11) 96543-2109",
//       "email": "julia.costa@email.com",
//       "data_nascimento": "2005-01-10T00:00:00Z"
//     },
//     {
//       "cod_aluno": 6,
//       "cod_turma": 104,
//       "nome": "Lucas Lima",
//       "cpf": "678.901.234-55",
//       "rg": "67.890.123-6",
//       "telefone_aluno": "(11) 96789-0123",
//       "telefone_responsavel": "(11) 95432-1098",
//       "email": "lucas.lima@email.com",
//       "data_nascimento": "2004-09-05T00:00:00Z"
//     },
//     {
//       "cod_aluno": 7,
//       "cod_turma": 103,
//       "nome": "Carla Martins",
//       "cpf": "789.012.345-66",
//       "rg": "78.901.234-7",
//       "telefone_aluno": "(11) 97890-1234",
//       "telefone_responsavel": "(11) 94321-0987",
//       "email": "carla.martins@email.com",
//       "data_nascimento": "2006-07-20T00:00:00Z"
//     },
//     {
//       "cod_aluno": 8,
//       "cod_turma": 101,
//       "nome": "Bruno Ferreira",
//       "cpf": "890.123.456-77",
//       "rg": "89.012.345-8",
//       "telefone_aluno": "(11) 98901-2345",
//       "telefone_responsavel": "(11) 93210-9876",
//       "email": "bruno.ferreira@email.com",
//       "data_nascimento": "2005-06-25T00:00:00Z"
//     },
//     {
//       "cod_aluno": 9,
//       "cod_turma": 104,
//       "nome": "Larissa Rocha",
//       "cpf": "901.234.567-88",
//       "rg": "90.123.456-9",
//       "telefone_aluno": "(11) 99012-3456",
//       "telefone_responsavel": "(11) 92109-8765",
//       "email": "larissa.rocha@email.com",
//       "data_nascimento": "2004-12-18T00:00:00Z"
//     },
//     {
//       "cod_aluno": 10,
//       "cod_turma": 102,
//       "nome": "Rafael Mendes",
//       "cpf": "012.345.678-99",
//       "rg": "01.234.567-0",
//       "telefone_aluno": "(11) 90123-4567",
//       "telefone_responsavel": "(11) 91098-7654",
//       "email": "rafael.mendes@email.com",
//       "data_nascimento": "2003-02-14T00:00:00Z"
//     }
//   ]
// );

// /* Listar todos os alunos*/
// db['bd3-nosql-atv1'].find();

// /* Listar um aluno pelo CPF sem o campo de “cod_aluno” */
// db['LIVRARIA'].find(
//     { cpf: "123.456.789-00" },
//     { cod_aluno: 0 }
// );
// /* Atualiza os dados de todos os arquivos sem critério*/
// db['LIVRARIA'].update(
//     { cod_aluno: 1 },
//     { $set: { nome: "Maria Souza", cpf: "987.654.321-00", rg: "12.345.678-9" } }
// );

// /*Excluir um aluno: */
// db['LIVRARIA'].deleteOne({cod_aluno:'1'})
