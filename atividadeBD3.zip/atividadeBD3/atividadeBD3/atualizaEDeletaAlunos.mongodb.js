const database =  'BD3-NoSQL-AtlasMongoDB';
const collection =  'bd3-nosql-atv1';
use(database);




/* Alterar o nome de um aluno, cpf e o rg de um aluno*/
db['bd3-nosql-atv1'].update(
    { cod_aluno: 1 },
    { $set: { nome: "Maria Souza", cpf: "987.654.321-00", rg: "12.345.678-9" } }
);

/*Excluir um aluno: */
db['bd3-nosql-atv1'].deleteOne({cod_aluno:1})