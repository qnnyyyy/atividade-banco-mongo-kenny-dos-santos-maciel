const database =  'BD3-NoSQL-AtlasMongoDB';
const collection =  'bd3-nosql-atv1';
use(database);





/* Listar todos os alunos*/
db['bd3-nosql-atv1'].find();


/* Listar um aluno pelo CPF sem o campo de “cod_aluno” */
// db['bd3-nosql-atv1'].find(
//     { cpf: "123.456.789-00" },
//     { cod_aluno:1 }
// );